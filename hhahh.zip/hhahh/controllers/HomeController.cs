﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using 兰州拉面.controllers;
using 兰州拉面.Models;
using 兰州拉面.ViewModels;

namespace 兰州拉面.controllers
{
    //[Route("[controller]/[action]")]
    public class HomeController : Controller
    {
        private INoodleRepository _noodleRepository;
        private IFeedbackRepository _feedbackRepository;
        public HomeController (INoodleRepository noodleRepository ,IFeedbackRepository feedbackRepository)
        {
            _noodleRepository = noodleRepository;
            _feedbackRepository = feedbackRepository;
        }
      
        public IActionResult  Index()
        {
            // var Noodles= _noodleRepository.GetAllNoodles();//调用面条仓库
            var viewModel = new HomeViewModel()
            {
                Feedbacks = _feedbackRepository.GetAllFeedbacks().ToList(),
                Noodles = _noodleRepository.GetAllNoodles().ToList()
            };
            return View (viewModel);
        }

        public string About()
        {
            return "welcome wzz";
        }
        public IActionResult Detail(int id)
        {
            return View(_noodleRepository.GetNoodleById(id));
        }
    }
}
