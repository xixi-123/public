﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
namespace 兰州拉面.controllers
{
    [Controller]
    public class Test : Controller//添加Controller的三种方法TestController,[Controller]和Test：Controller
    {
        public ActionResult  Index()
        {
            return Content("welcome to test home");
        }

        public string About()
        {
            return "welcome tst wzz";
        }
        public ActionResult Contact()
        {
            return View();
        }
    }
}
