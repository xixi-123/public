﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace 兰州拉面.controllers
{
    public class NoodleController : Controller
    {
        public IList<string> Index()
        {
            return new List<string>{"牛肉面","羊肉面","猪肉炖粉条"};
        }
    }
}
