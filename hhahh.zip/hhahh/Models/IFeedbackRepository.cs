﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace 兰州拉面.Models
{
    public interface IFeedbackRepository
    {
        IEnumerable<Feedback> GetAllFeedbacks();//创建名称GetALLFeedbacks为接口
        void AddFeedback(Feedback feedback);
    }
}
